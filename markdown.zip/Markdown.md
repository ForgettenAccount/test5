# This is Heading 1
## This is Heading 2
### This is Heading 3
#### This is Heading 4
##### This is Heading 5
###### This is Heading 6

This is a normal text

*This is emphasized text*

_and a another emphasized text_

**This is a bold text**

**You** _can_ combine ***them***

This is [link](#)

![This is a image](#)

+ This is a item
   - This is a sub-item
      * This is a deeper sub-item
   - This is a sub-item
+ This is a item

> This is a blockquote

```
This is a codeline
```

`and another codeline`

File Info
```
Filename: Markdown.md
File size: 0.71KB (714B)
File location: /storage/emulated/0/Download/(2) QuickEdit Test/Markdown.md/
File type: Markdown
```